package simplexe;

/** 
 * Sert à caracteriser la methode entrante
 */
public enum MethodeEntrante {
		PREMIERE, PLUS_GRAND, PLUS_AVANTAGEUSE;
}
